-- ===================================================================
-- Script de creacion de la base de datos del sistema de Notas de Alumnos.
-- Esquema compatible con AlumnosContext.cs (tablas en plural) y con la API.
-- Equivalente a BD/baseDatosAlumnos_creacion.sql.
-- Re-ejecutable: no borra datos, solo crea lo que no existe.
-- Ejecutar en SQL Server / LocalDB:
--   sqlcmd -S "(localdb)\MSSQLLocalDB" -E -i setup.sql
-- ===================================================================
USE [master]
GO
IF DB_ID(N'baseDatosAlumnos') IS NULL
    CREATE DATABASE [baseDatosAlumnos]
GO
USE [baseDatosAlumnos]
GO
IF OBJECT_ID(N'dbo.ALUMNOS', N'U') IS NULL
CREATE TABLE [dbo].[ALUMNOS] (
    [COD_ALUMNO] [int] NOT NULL,
    [NOMBRES]    [nvarchar](100) NOT NULL,
    [APELLIDOS]  [nvarchar](100) NOT NULL,
    CONSTRAINT [PK_ALUMNOS] PRIMARY KEY CLUSTERED ([COD_ALUMNO] ASC)
)
GO
IF OBJECT_ID(N'dbo.ASIGNATURAS', N'U') IS NULL
CREATE TABLE [dbo].[ASIGNATURAS] (
    [ID_ASIGNATURA]  [int] IDENTITY(1,1) NOT NULL,
    [NOM_ASIGNATURA] [nvarchar](100) NOT NULL,
    CONSTRAINT [PK_ASIGNATURAS] PRIMARY KEY CLUSTERED ([ID_ASIGNATURA] ASC),
    CONSTRAINT [UQ_ASIGNATURAS_NOMBRE] UNIQUE ([NOM_ASIGNATURA])
)
GO
IF OBJECT_ID(N'dbo.NOTAS', N'U') IS NULL
CREATE TABLE [dbo].[NOTAS] (
    [ID_NOTA]        [int] IDENTITY(1,1) NOT NULL,
    [NOTA]           [decimal](2,1) NOT NULL,
    [N_NOTA]         [int] NOT NULL,
    [COD_ALUMNO]     [int] NOT NULL,
    [ID_ASIGNATURA]  [int] NOT NULL,
    CONSTRAINT [PK_NOTAS] PRIMARY KEY CLUSTERED ([ID_NOTA] ASC),
    CONSTRAINT [FK_NOTAS_ALUMNOS] FOREIGN KEY ([COD_ALUMNO]) REFERENCES [dbo].[ALUMNOS]([COD_ALUMNO]),
    CONSTRAINT [FK_NOTAS_ASIGNATURAS] FOREIGN KEY ([ID_ASIGNATURA]) REFERENCES [dbo].[ASIGNATURAS]([ID_ASIGNATURA]),
    CONSTRAINT [CK_NOTAS_N_NOTA] CHECK ([N_NOTA] BETWEEN 1 AND 3),
    CONSTRAINT [CK_NOTAS_NOTA] CHECK ([NOTA] BETWEEN 1.0 AND 7.0),
    CONSTRAINT [UQ_NOTAS_ALUMNO_ASIGNATURA_NNOTA] UNIQUE ([COD_ALUMNO], [ID_ASIGNATURA], [N_NOTA])
)
GO
-- Indices para las consultas por alumno y por asignatura.
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_NOTAS_COD_ALUMNO' AND object_id = OBJECT_ID(N'dbo.NOTAS'))
    CREATE INDEX [IX_NOTAS_COD_ALUMNO] ON [dbo].[NOTAS] ([COD_ALUMNO])
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_NOTAS_ID_ASIGNATURA' AND object_id = OBJECT_ID(N'dbo.NOTAS'))
    CREATE INDEX [IX_NOTAS_ID_ASIGNATURA] ON [dbo].[NOTAS] ([ID_ASIGNATURA])
GO
PRINT 'Base de datos y tablas compatibles con la API: listo.'
GO
