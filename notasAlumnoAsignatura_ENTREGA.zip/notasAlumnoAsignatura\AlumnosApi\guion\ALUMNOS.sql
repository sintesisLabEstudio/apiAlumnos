-- ===================================================================
-- Script de base de datos compatible con AlumnosContext.cs y la API.
-- Crea la BD baseDatosAlumnos y las tablas ALUMNOS, ASIGNATURAS y NOTAS.
-- Mismo esquema que BD/baseDatosAlumnos_creacion.sql.
-- Re-ejecutable: no borra datos, solo crea lo que no existe.
-- ===================================================================
USE [master]
GO
IF DB_ID(N'baseDatosAlumnos') IS NULL
    CREATE DATABASE [baseDatosAlumnos]
GO
USE [baseDatosAlumnos]
GO
-- ALUMNOS: COD_ALUMNO lo ingresa el usuario (ValueGeneratedNever en el contexto).
IF OBJECT_ID(N'dbo.ALUMNOS', N'U') IS NULL
CREATE TABLE [dbo].[ALUMNOS](
    [COD_ALUMNO] [int] NOT NULL,
    [NOMBRES]    [nvarchar](100) NOT NULL,
    [APELLIDOS]  [nvarchar](100) NOT NULL,
    CONSTRAINT [PK_ALUMNOS] PRIMARY KEY CLUSTERED ([COD_ALUMNO] ASC)
)
GO
-- ASIGNATURAS: ID_ASIGNATURA autonumerico y nombre unico (la API tambien lo valida).
IF OBJECT_ID(N'dbo.ASIGNATURAS', N'U') IS NULL
CREATE TABLE [dbo].[ASIGNATURAS](
    [ID_ASIGNATURA]  [int] IDENTITY(1,1) NOT NULL,
    [NOM_ASIGNATURA] [nvarchar](100) NOT NULL,
    CONSTRAINT [PK_ASIGNATURAS] PRIMARY KEY CLUSTERED ([ID_ASIGNATURA] ASC),
    CONSTRAINT [UQ_ASIGNATURAS_NOMBRE] UNIQUE ([NOM_ASIGNATURA])
)
GO
-- NOTAS: hasta 3 notas por alumno y asignatura; N_NOTA indica cual (1, 2 o 3).
IF OBJECT_ID(N'dbo.NOTAS', N'U') IS NULL
CREATE TABLE [dbo].[NOTAS](
    [ID_NOTA]        [int] IDENTITY(1,1) NOT NULL,
    [NOTA]           [decimal](2,1) NOT NULL,
    [N_NOTA]         [int] NOT NULL,
    [COD_ALUMNO]     [int] NOT NULL,
    [ID_ASIGNATURA]  [int] NOT NULL,
    CONSTRAINT [PK_NOTAS] PRIMARY KEY CLUSTERED ([ID_NOTA] ASC),
    CONSTRAINT [FK_NOTAS_ALUMNOS] FOREIGN KEY ([COD_ALUMNO]) REFERENCES [dbo].[ALUMNOS]([COD_ALUMNO]),
    CONSTRAINT [FK_NOTAS_ASIGNATURAS] FOREIGN KEY ([ID_ASIGNATURA]) REFERENCES [dbo].[ASIGNATURAS]([ID_ASIGNATURA]),
    CONSTRAINT [CK_NOTAS_N_NOTA] CHECK ([N_NOTA] BETWEEN 1 AND 3),
    CONSTRAINT [CK_NOTAS_NOTA] CHECK ([NOTA] BETWEEN 1.0 AND 7.0),
    CONSTRAINT [UQ_NOTAS_ALUMNO_ASIGNATURA_NNOTA] UNIQUE ([COD_ALUMNO], [ID_ASIGNATURA], [N_NOTA])
)
GO
